package main;

/**
 * A position in the maze is given by a pair of cartesian coordinates.
 * @author Victor
 */
public class Position {
	private final int x, y;
	
	Position(int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	@Override public String toString() {
		return "[" + x + ',' + y + "]";
	}
}
