package main;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * Possible directions in a Von Neumann neighborhood.
 * @author Victor
 */
public enum Direction {
	WEST  (-1,  0),
	EAST  ( 1,  0),
	NORTH ( 0, -1),
	SOUTH ( 0,  1);

	public int x;
	public int y;

	Direction(int x, int y) {
		this.x = x;
		this.y = y;
	}

	/** Reusable list containing all directions. */
	private static List<Direction> values = Arrays.asList(Direction.values());

	/**
	 * Returns a list containing all directions in a pseudo-random order.
	 * Doesn't construct a new list.
	 */
	public static List<Direction> shuffled() {
		Collections.shuffle(values);
		return values;
	}
}
