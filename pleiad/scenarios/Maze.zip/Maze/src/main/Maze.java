package main;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.LinkedList;
import java.util.Random;

import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * @author Victor
 */
@SuppressWarnings("serial")
public class Maze extends Canvas {
	
	/**
	 * The two-dimensional grid of tiles composing this maze.
	 */
	private final Tile[][] maze;
	
	/**
	 * The shortest path from the entrance to the exit, represented
	 * as an ordered list of positions.
	 */
	private final List<Position> solution = new LinkedList<Position>();

	/**
	 * Creates and displays a maze with the specified dimensions.
	 */
	public Maze(int width, int height) {

		// GUI shenanigans
		setSize(width * 10, height * 10);
		JFrame frame = new JFrame("Maze of Death");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		frame.add(this);
		frame.pack();

		// Initialization
		maze = new Tile[height][width];

		do {
			// Fill the maze with walls
			for (int x = 0; x < width; x++) {
				for (int y = 0; y < height; y++) {
					maze[y][x] = Tile.WALL;
				}
			}
			
			// Place the entrance and the exit
			//TODO could be randomized
			maze[1][0] = Tile.ENTRANCE;
			maze[height - 2][width - 1] = Tile.EXIT;
			
			solution.clear();
		} while (!make(1, 1)); // if `make` returns false, there's no solution
		
		// Add the entrance to the solution
		solution.add(0, new Position(0, 1));
		
		// Redraws the maze on screen (in case Swing attempted to draw it during the generation)
		repaint();
	}

	/**
	 * Main entry point. Generates and displays a maze.
	 * @param args The coordinates of the maze to generate. First argument
	 * is the desired width, second is the height. Both should be odd.
	 */
	public static void main(String[] args) {
		new Maze(Integer.valueOf(args[0]), Integer.valueOf(args[1])).kprint();
	}

	/**
	 * Generates the maze itself.
	 * The maze is initially filled with walls. This function carves corridors, starting
	 * at the tile with the specified coordinates, using the following algorithm:
	 * For each direction (in a random order),
	 * 		If it's okay (i.e. it's not out of bounds and doesn't backtrack),
	 * 			Carve two tiles in this direction,
	 * 			Recurse at the new point.
	 * 
	 * @return whether the specified tile is part of the solution
	 */
	boolean make(int x, int y) {
		
		maze[y][x] = Tile.EMPTY;
		
		boolean ok = false;
		
		for (Direction d : Direction.shuffled()) {
			
			int x2 = x + 2 * d.x;
			int y2 = y + 2 * d.y;
			boolean leadsToExit = maze[y + d.y][x + d.x] == Tile.EXIT;
			
			if (x2 < maze.length & y2 < maze[0].length & x2 >= 0 & y2 >= 0
					&& maze[y2][x2] == Tile.WALL) {
				// This direction doesn't lead out of bounds nor backtrack
				
				// Clear tiles in this direction
				maze[y + d.y][x + d.x] = Tile.EMPTY;
				
				// Recurse at the new point
				leadsToExit |= make(x2, y2);
			}
			
			if (leadsToExit) {
	            // This tile is part of the solution iff one direction leads to the exit
				ok = true;
				solution.add(0, new Position(x + d.x, y + d.y));
				solution.add(0, new Position(x, y));
			}
		}
		
		return ok;
	}

	///////////////////////
	// DISPLAY FUNCTIONS //
	///////////////////////
	
	/**
	 * Prints prolog code describing this maze.
	 */
	private void kprint() {
		for (int x = 0; x < maze.length; x++) {
			for (int y = 0; y < maze[x].length; y++) {
				System.out.printf(":- kassert(position(%d, %d, %s)).\n",
						x, y, maze[y][x].toString());
			}
		}
		System.out.printf(":- kassert(solution(%s)).\n", solution);
	}

	/**
	 * Draws this maze on screen.
	 */
	@Override public void paint(Graphics g) {
		for (int x = 0; x < maze.length; x++) {
			for (int y = 0; y < maze[x].length; y++) {
				g.setColor(colorOfTile(maze[y][x]));
				g.fillRect(x * 10, y * 10, 10, 10);
			}
		}
	}
	
	/** Helper function returning the color associated with a given Tile. */
	private static Color colorOfTile(Tile tile) {
		return tile == Tile.EMPTY      ? Color.WHITE:
			   tile == Tile.ENTRANCE   ? Color.WHITE:
			   tile == Tile.EXIT       ? Color.WHITE:
			   tile == Tile.WALL       ? Color.BLACK:
			   tile instanceof Item    ? Color.YELLOW:
			   tile instanceof Monster ? Color.RED:
			   /* default */             null;
	}
}
