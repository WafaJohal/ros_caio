package main;

/**
 * @author Victor
 */
public class Monster extends Tile {

	public Monster() {
		super("monster");
	}
	
	//TODO
}
