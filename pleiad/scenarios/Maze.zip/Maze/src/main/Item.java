package main;

/**
 * @author Victor
 */
public class Item extends Tile {

	public Item() {
		super("item");
	}
	
	//TODO
}
