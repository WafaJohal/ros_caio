package main;

/**
 * A single cell of the Maze.
 * This class doesn't manage tile coordinates: Maze does.
 * @author Victor
 */
public class Tile {

	/** Constant representing an empty Tile. */
	public static final Tile EMPTY = new Tile("empty");
	
	public static final Tile ENTRANCE = new Tile("entrance");
	
	public static final Tile EXIT = new Tile("exit");
	
	/**
	 * Walls contain no information, thus all of them can be represented by a single constant.
	 */
	public static final Tile WALL = new Tile("wall");
	
	public String name;
	
	public Tile(String name) {
		this.name = name;
	}
	
	@Override public String toString() {
		return name;
	}
}
